"""Importaciones agrupadas de capas de pooling."""

from .average_pooling2d import AveragePooling2D
from .global_average_pooling2d import GlobalAveragePooling2D
from .global_max_pooling2d import GlobalMaxPooling2D
from .max_pooling1d import MaxPooling1D
from .max_pooling2d import MaxPooling2D

__all__ = [
    "MaxPooling1D",
    "MaxPooling2D",
    "AveragePooling2D",
    "GlobalAveragePooling2D",
    "GlobalMaxPooling2D",
]
