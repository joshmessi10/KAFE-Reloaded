# Generated from Kafe_Grammar.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,65,460,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        1,0,1,0,1,0,5,0,84,8,0,10,0,12,0,87,9,0,1,0,1,0,1,0,5,0,92,8,0,10,
        0,12,0,95,9,0,1,1,1,1,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,
        2,1,2,1,2,3,2,112,8,2,1,3,1,3,1,3,5,3,117,8,3,10,3,12,3,120,9,3,
        1,4,1,4,1,4,1,4,1,4,1,4,1,4,5,4,129,8,4,10,4,12,4,132,9,4,3,4,134,
        8,4,1,4,1,4,1,4,1,4,3,4,140,8,4,1,5,1,5,1,5,1,5,3,5,146,8,5,1,6,
        1,6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,4,8,161,8,8,11,8,
        12,8,162,1,9,1,9,1,9,1,9,3,9,169,8,9,1,9,1,9,1,9,1,9,1,9,1,9,1,10,
        1,10,1,10,5,10,180,8,10,10,10,12,10,183,9,10,1,11,1,11,1,11,1,11,
        1,12,1,12,1,12,3,12,192,8,12,1,12,1,12,1,12,1,12,1,13,1,13,1,13,
        5,13,201,8,13,10,13,12,13,204,9,13,1,14,1,14,1,14,3,14,209,8,14,
        1,14,1,14,1,14,3,14,214,8,14,1,14,5,14,217,8,14,10,14,12,14,220,
        9,14,1,15,1,15,1,15,5,15,225,8,15,10,15,12,15,228,9,15,1,16,1,16,
        3,16,232,8,16,1,17,1,17,1,17,1,17,1,17,1,17,1,18,1,18,1,18,1,19,
        1,19,1,19,1,19,1,19,1,20,1,20,1,20,1,20,1,20,1,21,1,21,1,21,1,21,
        1,21,1,21,1,21,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,23,1,23,1,23,
        1,23,1,23,1,24,1,24,1,24,1,24,1,24,1,24,1,24,5,24,279,8,24,10,24,
        12,24,282,9,24,1,24,1,24,1,24,3,24,287,8,24,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,27,1,27,1,27,
        1,27,1,27,1,27,1,27,1,27,1,27,1,28,1,28,1,29,1,29,1,29,5,29,317,
        8,29,10,29,12,29,320,9,29,1,30,1,30,1,30,5,30,325,8,30,10,30,12,
        30,328,9,30,1,31,1,31,1,31,5,31,333,8,31,10,31,12,31,336,9,31,1,
        32,1,32,1,32,5,32,341,8,32,10,32,12,32,344,9,32,1,33,1,33,1,33,5,
        33,349,8,33,10,33,12,33,352,9,33,1,34,1,34,1,34,5,34,357,8,34,10,
        34,12,34,360,9,34,1,35,1,35,1,35,3,35,365,8,35,1,36,1,36,1,36,1,
        36,1,36,1,36,1,36,1,36,1,36,1,36,3,36,377,8,36,1,36,1,36,3,36,381,
        8,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,1,36,1,36,3,36,412,8,36,1,36,1,36,1,36,1,36,1,36,5,36,
        419,8,36,10,36,12,36,422,9,36,1,37,1,37,1,37,1,37,1,37,3,37,429,
        8,37,1,38,1,38,1,38,1,38,5,38,435,8,38,10,38,12,38,438,9,38,3,38,
        440,8,38,1,38,1,38,1,39,1,39,1,39,1,39,1,39,1,39,1,39,1,39,1,39,
        1,39,1,39,1,39,1,39,1,39,3,39,458,8,39,1,39,0,1,72,40,0,2,4,6,8,
        10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,
        54,56,58,60,62,64,66,68,70,72,74,76,78,0,6,1,0,29,30,1,0,31,32,1,
        0,33,36,1,0,23,24,1,0,25,27,2,0,24,24,39,39,486,0,85,1,0,0,0,2,96,
        1,0,0,0,4,111,1,0,0,0,6,118,1,0,0,0,8,139,1,0,0,0,10,141,1,0,0,0,
        12,147,1,0,0,0,14,151,1,0,0,0,16,160,1,0,0,0,18,164,1,0,0,0,20,176,
        1,0,0,0,22,184,1,0,0,0,24,188,1,0,0,0,26,197,1,0,0,0,28,205,1,0,
        0,0,30,221,1,0,0,0,32,231,1,0,0,0,34,233,1,0,0,0,36,239,1,0,0,0,
        38,242,1,0,0,0,40,247,1,0,0,0,42,252,1,0,0,0,44,259,1,0,0,0,46,266,
        1,0,0,0,48,271,1,0,0,0,50,288,1,0,0,0,52,295,1,0,0,0,54,302,1,0,
        0,0,56,311,1,0,0,0,58,313,1,0,0,0,60,321,1,0,0,0,62,329,1,0,0,0,
        64,337,1,0,0,0,66,345,1,0,0,0,68,353,1,0,0,0,70,364,1,0,0,0,72,411,
        1,0,0,0,74,428,1,0,0,0,76,430,1,0,0,0,78,457,1,0,0,0,80,81,3,2,1,
        0,81,82,5,46,0,0,82,84,1,0,0,0,83,80,1,0,0,0,84,87,1,0,0,0,85,83,
        1,0,0,0,85,86,1,0,0,0,86,93,1,0,0,0,87,85,1,0,0,0,88,89,3,4,2,0,
        89,90,5,46,0,0,90,92,1,0,0,0,91,88,1,0,0,0,92,95,1,0,0,0,93,91,1,
        0,0,0,93,94,1,0,0,0,94,1,1,0,0,0,95,93,1,0,0,0,96,97,5,22,0,0,97,
        98,5,62,0,0,98,3,1,0,0,0,99,112,3,10,5,0,100,112,3,12,6,0,101,112,
        3,14,7,0,102,112,3,18,9,0,103,112,3,48,24,0,104,112,3,52,26,0,105,
        112,3,54,27,0,106,112,3,36,18,0,107,112,3,38,19,0,108,112,3,42,21,
        0,109,112,3,44,22,0,110,112,3,56,28,0,111,99,1,0,0,0,111,100,1,0,
        0,0,111,101,1,0,0,0,111,102,1,0,0,0,111,103,1,0,0,0,111,104,1,0,
        0,0,111,105,1,0,0,0,111,106,1,0,0,0,111,107,1,0,0,0,111,108,1,0,
        0,0,111,109,1,0,0,0,111,110,1,0,0,0,112,5,1,0,0,0,113,114,3,4,2,
        0,114,115,5,46,0,0,115,117,1,0,0,0,116,113,1,0,0,0,117,120,1,0,0,
        0,118,116,1,0,0,0,118,119,1,0,0,0,119,7,1,0,0,0,120,118,1,0,0,0,
        121,122,5,62,0,0,122,123,5,1,0,0,123,124,5,62,0,0,124,133,5,40,0,
        0,125,130,3,56,28,0,126,127,5,47,0,0,127,129,3,56,28,0,128,126,1,
        0,0,0,129,132,1,0,0,0,130,128,1,0,0,0,130,131,1,0,0,0,131,134,1,
        0,0,0,132,130,1,0,0,0,133,125,1,0,0,0,133,134,1,0,0,0,134,135,1,
        0,0,0,135,140,5,41,0,0,136,137,5,62,0,0,137,138,5,1,0,0,138,140,
        5,62,0,0,139,121,1,0,0,0,139,136,1,0,0,0,140,9,1,0,0,0,141,142,3,
        78,39,0,142,145,5,62,0,0,143,144,5,38,0,0,144,146,3,56,28,0,145,
        143,1,0,0,0,145,146,1,0,0,0,146,11,1,0,0,0,147,148,5,62,0,0,148,
        149,5,38,0,0,149,150,3,56,28,0,150,13,1,0,0,0,151,152,5,62,0,0,152,
        153,3,16,8,0,153,154,5,38,0,0,154,155,3,56,28,0,155,15,1,0,0,0,156,
        157,5,42,0,0,157,158,3,56,28,0,158,159,5,43,0,0,159,161,1,0,0,0,
        160,156,1,0,0,0,161,162,1,0,0,0,162,160,1,0,0,0,162,163,1,0,0,0,
        163,17,1,0,0,0,164,165,5,9,0,0,165,166,5,62,0,0,166,168,5,40,0,0,
        167,169,3,20,10,0,168,167,1,0,0,0,168,169,1,0,0,0,169,170,1,0,0,
        0,170,171,5,41,0,0,171,172,5,37,0,0,172,173,3,78,39,0,173,174,5,
        44,0,0,174,175,3,6,3,0,175,19,1,0,0,0,176,181,3,22,11,0,177,178,
        5,47,0,0,178,180,3,22,11,0,179,177,1,0,0,0,180,183,1,0,0,0,181,179,
        1,0,0,0,181,182,1,0,0,0,182,21,1,0,0,0,183,181,1,0,0,0,184,185,5,
        62,0,0,185,186,5,44,0,0,186,187,3,78,39,0,187,23,1,0,0,0,188,189,
        5,20,0,0,189,191,5,40,0,0,190,192,3,26,13,0,191,190,1,0,0,0,191,
        192,1,0,0,0,192,193,1,0,0,0,193,194,5,41,0,0,194,195,5,37,0,0,195,
        196,3,78,39,0,196,25,1,0,0,0,197,202,3,78,39,0,198,199,5,47,0,0,
        199,201,3,78,39,0,200,198,1,0,0,0,201,204,1,0,0,0,202,200,1,0,0,
        0,202,203,1,0,0,0,203,27,1,0,0,0,204,202,1,0,0,0,205,206,5,62,0,
        0,206,208,5,40,0,0,207,209,3,30,15,0,208,207,1,0,0,0,208,209,1,0,
        0,0,209,210,1,0,0,0,210,218,5,41,0,0,211,213,5,40,0,0,212,214,3,
        30,15,0,213,212,1,0,0,0,213,214,1,0,0,0,214,215,1,0,0,0,215,217,
        5,41,0,0,216,211,1,0,0,0,217,220,1,0,0,0,218,216,1,0,0,0,218,219,
        1,0,0,0,219,29,1,0,0,0,220,218,1,0,0,0,221,226,3,32,16,0,222,223,
        5,47,0,0,223,225,3,32,16,0,224,222,1,0,0,0,225,228,1,0,0,0,226,224,
        1,0,0,0,226,227,1,0,0,0,227,31,1,0,0,0,228,226,1,0,0,0,229,232,3,
        56,28,0,230,232,3,34,17,0,231,229,1,0,0,0,231,230,1,0,0,0,232,33,
        1,0,0,0,233,234,5,40,0,0,234,235,3,20,10,0,235,236,5,41,0,0,236,
        237,5,37,0,0,237,238,3,56,28,0,238,35,1,0,0,0,239,240,5,15,0,0,240,
        241,3,56,28,0,241,37,1,0,0,0,242,243,5,11,0,0,243,244,5,40,0,0,244,
        245,3,56,28,0,245,246,5,41,0,0,246,39,1,0,0,0,247,248,5,10,0,0,248,
        249,5,40,0,0,249,250,3,56,28,0,250,251,5,41,0,0,251,41,1,0,0,0,252,
        253,5,14,0,0,253,254,5,40,0,0,254,255,3,56,28,0,255,256,5,47,0,0,
        256,257,3,56,28,0,257,258,5,41,0,0,258,43,1,0,0,0,259,260,5,13,0,
        0,260,261,5,40,0,0,261,262,3,56,28,0,262,263,5,47,0,0,263,264,3,
        56,28,0,264,265,5,41,0,0,265,45,1,0,0,0,266,267,5,12,0,0,267,268,
        5,40,0,0,268,269,3,56,28,0,269,270,5,41,0,0,270,47,1,0,0,0,271,272,
        5,16,0,0,272,273,5,40,0,0,273,274,3,56,28,0,274,275,5,41,0,0,275,
        276,5,44,0,0,276,280,3,6,3,0,277,279,3,50,25,0,278,277,1,0,0,0,279,
        282,1,0,0,0,280,278,1,0,0,0,280,281,1,0,0,0,281,286,1,0,0,0,282,
        280,1,0,0,0,283,284,5,18,0,0,284,285,5,44,0,0,285,287,3,6,3,0,286,
        283,1,0,0,0,286,287,1,0,0,0,287,49,1,0,0,0,288,289,5,17,0,0,289,
        290,5,40,0,0,290,291,3,56,28,0,291,292,5,41,0,0,292,293,5,44,0,0,
        293,294,3,6,3,0,294,51,1,0,0,0,295,296,5,2,0,0,296,297,5,40,0,0,
        297,298,3,56,28,0,298,299,5,41,0,0,299,300,5,44,0,0,300,301,3,6,
        3,0,301,53,1,0,0,0,302,303,5,3,0,0,303,304,5,40,0,0,304,305,5,62,
        0,0,305,306,5,4,0,0,306,307,3,56,28,0,307,308,5,41,0,0,308,309,5,
        44,0,0,309,310,3,6,3,0,310,55,1,0,0,0,311,312,3,58,29,0,312,57,1,
        0,0,0,313,318,3,60,30,0,314,315,7,0,0,0,315,317,3,60,30,0,316,314,
        1,0,0,0,317,320,1,0,0,0,318,316,1,0,0,0,318,319,1,0,0,0,319,59,1,
        0,0,0,320,318,1,0,0,0,321,326,3,62,31,0,322,323,7,1,0,0,323,325,
        3,62,31,0,324,322,1,0,0,0,325,328,1,0,0,0,326,324,1,0,0,0,326,327,
        1,0,0,0,327,61,1,0,0,0,328,326,1,0,0,0,329,334,3,64,32,0,330,331,
        7,2,0,0,331,333,3,64,32,0,332,330,1,0,0,0,333,336,1,0,0,0,334,332,
        1,0,0,0,334,335,1,0,0,0,335,63,1,0,0,0,336,334,1,0,0,0,337,342,3,
        66,33,0,338,339,7,3,0,0,339,341,3,66,33,0,340,338,1,0,0,0,341,344,
        1,0,0,0,342,340,1,0,0,0,342,343,1,0,0,0,343,65,1,0,0,0,344,342,1,
        0,0,0,345,350,3,68,34,0,346,347,7,4,0,0,347,349,3,68,34,0,348,346,
        1,0,0,0,349,352,1,0,0,0,350,348,1,0,0,0,350,351,1,0,0,0,351,67,1,
        0,0,0,352,350,1,0,0,0,353,358,3,70,35,0,354,355,5,28,0,0,355,357,
        3,70,35,0,356,354,1,0,0,0,357,360,1,0,0,0,358,356,1,0,0,0,358,359,
        1,0,0,0,359,69,1,0,0,0,360,358,1,0,0,0,361,362,7,5,0,0,362,365,3,
        70,35,0,363,365,3,72,36,0,364,361,1,0,0,0,364,363,1,0,0,0,365,71,
        1,0,0,0,366,367,6,36,-1,0,367,412,3,8,4,0,368,412,3,28,14,0,369,
        412,3,40,20,0,370,412,3,46,23,0,371,372,5,21,0,0,372,373,5,40,0,
        0,373,376,3,56,28,0,374,375,5,47,0,0,375,377,3,56,28,0,376,374,1,
        0,0,0,376,377,1,0,0,0,377,380,1,0,0,0,378,379,5,47,0,0,379,381,3,
        56,28,0,380,378,1,0,0,0,380,381,1,0,0,0,381,382,1,0,0,0,382,383,
        5,41,0,0,383,412,1,0,0,0,384,385,5,5,0,0,385,386,5,40,0,0,386,387,
        3,56,28,0,387,388,5,41,0,0,388,412,1,0,0,0,389,390,5,6,0,0,390,391,
        5,40,0,0,391,392,3,56,28,0,392,393,5,41,0,0,393,412,1,0,0,0,394,
        395,5,7,0,0,395,396,5,40,0,0,396,397,3,56,28,0,397,398,5,41,0,0,
        398,412,1,0,0,0,399,400,5,8,0,0,400,401,5,40,0,0,401,402,3,56,28,
        0,402,403,5,41,0,0,403,412,1,0,0,0,404,412,3,34,17,0,405,412,3,74,
        37,0,406,412,5,62,0,0,407,408,5,40,0,0,408,409,3,56,28,0,409,410,
        5,41,0,0,410,412,1,0,0,0,411,366,1,0,0,0,411,368,1,0,0,0,411,369,
        1,0,0,0,411,370,1,0,0,0,411,371,1,0,0,0,411,384,1,0,0,0,411,389,
        1,0,0,0,411,394,1,0,0,0,411,399,1,0,0,0,411,404,1,0,0,0,411,405,
        1,0,0,0,411,406,1,0,0,0,411,407,1,0,0,0,412,420,1,0,0,0,413,414,
        10,14,0,0,414,415,5,42,0,0,415,416,3,56,28,0,416,417,5,43,0,0,417,
        419,1,0,0,0,418,413,1,0,0,0,419,422,1,0,0,0,420,418,1,0,0,0,420,
        421,1,0,0,0,421,73,1,0,0,0,422,420,1,0,0,0,423,429,5,58,0,0,424,
        429,5,60,0,0,425,429,5,61,0,0,426,429,5,59,0,0,427,429,3,76,38,0,
        428,423,1,0,0,0,428,424,1,0,0,0,428,425,1,0,0,0,428,426,1,0,0,0,
        428,427,1,0,0,0,429,75,1,0,0,0,430,439,5,42,0,0,431,436,3,56,28,
        0,432,433,5,47,0,0,433,435,3,56,28,0,434,432,1,0,0,0,435,438,1,0,
        0,0,436,434,1,0,0,0,436,437,1,0,0,0,437,440,1,0,0,0,438,436,1,0,
        0,0,439,431,1,0,0,0,439,440,1,0,0,0,440,441,1,0,0,0,441,442,5,43,
        0,0,442,77,1,0,0,0,443,458,5,50,0,0,444,458,5,51,0,0,445,458,5,52,
        0,0,446,458,5,53,0,0,447,458,5,54,0,0,448,458,5,55,0,0,449,458,5,
        56,0,0,450,458,5,57,0,0,451,452,5,49,0,0,452,453,5,42,0,0,453,454,
        3,78,39,0,454,455,5,43,0,0,455,458,1,0,0,0,456,458,3,24,12,0,457,
        443,1,0,0,0,457,444,1,0,0,0,457,445,1,0,0,0,457,446,1,0,0,0,457,
        447,1,0,0,0,457,448,1,0,0,0,457,449,1,0,0,0,457,450,1,0,0,0,457,
        451,1,0,0,0,457,456,1,0,0,0,458,79,1,0,0,0,35,85,93,111,118,130,
        133,139,145,162,168,181,191,202,208,213,218,226,231,280,286,318,
        326,334,342,350,358,364,376,380,411,420,428,436,439,457
    ]

class Kafe_GrammarParser ( Parser ):

    grammarFileName = "Kafe_Grammar.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'.'", "'while'", "'for'", "'in'", "'int'", 
                     "'float'", "'str'", "'bool'", "'drip'", "'pour'", "'show'", 
                     "'len'", "'remove'", "'append'", "'return'", "'if'", 
                     "'elif'", "'else'", "'match'", "'FUNC'", "'range'", 
                     "'import'", "'+'", "'-'", "'*'", "'/'", "'%'", "'^'", 
                     "'&&'", "'||'", "'=='", "'!='", "'<'", "'>'", "'<='", 
                     "'>='", "'=>'", "'='", "'!'", "'('", "')'", "'['", 
                     "']'", "':'", "'|'", "';'", "','", "'_'", "'List'", 
                     "'INT'", "'FLOAT'", "'BOOL'", "'VOID'", "'STR'", "'GESHA'", 
                     "'PARDOS'", "'MACHINE'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "INT_CAST", "FLOAT_CAST", "STR_CAST", 
                      "BOOL_CAST", "DRIP", "POUR", "SHOW", "LEN", "REMOVE", 
                      "APPEND", "RETURN", "IF", "ELIF", "ELSE", "MATCH", 
                      "FUNC", "RANGE", "IMPORT", "ADD", "SUB", "MUL", "DIV", 
                      "MOD", "POW", "AND", "OR", "EQ", "NEQ", "LT", "GT", 
                      "LE", "GE", "ARROW", "ASSIGN", "NOT", "LPAREN", "RPAREN", 
                      "LBRACK", "RBRACK", "COLON", "PIPE", "SEMI", "COMMA", 
                      "UNDERSCORE", "LIST", "INT_TYPE", "FLOAT_TYPE", "BOOL_TYPE", 
                      "VOID_TYPE", "STRING_TYPE", "GESHA_TYPE", "PARDOS_TYPE", 
                      "MACHINE_TYPE", "INT", "BOOL", "FLOAT", "STRING", 
                      "ID", "LINE_COMMENT", "BLOCK_COMMENT", "WS" ]

    RULE_program = 0
    RULE_simpleImport = 1
    RULE_stmt = 2
    RULE_block = 3
    RULE_object = 4
    RULE_varDecl = 5
    RULE_assignStmt = 6
    RULE_indexedAssignStmt = 7
    RULE_indexing = 8
    RULE_functionDecl = 9
    RULE_paramList = 10
    RULE_paramDecl = 11
    RULE_functionParam = 12
    RULE_paramList_typeDecl = 13
    RULE_functionCall = 14
    RULE_argList = 15
    RULE_arg = 16
    RULE_lambdaExpr = 17
    RULE_returnStmt = 18
    RULE_showStmt = 19
    RULE_pourStmt = 20
    RULE_appendCall = 21
    RULE_removeCall = 22
    RULE_lenCall = 23
    RULE_ifElseExpr = 24
    RULE_elifBranch = 25
    RULE_whileLoop = 26
    RULE_forLoop = 27
    RULE_expr = 28
    RULE_logicExpr = 29
    RULE_equalityExpr = 30
    RULE_relationalExpr = 31
    RULE_additiveExpr = 32
    RULE_multiplicativeExpr = 33
    RULE_powerExpr = 34
    RULE_unaryExpr = 35
    RULE_primaryExpr = 36
    RULE_literal = 37
    RULE_listLiteral = 38
    RULE_typeDecl = 39

    ruleNames =  [ "program", "simpleImport", "stmt", "block", "object", 
                   "varDecl", "assignStmt", "indexedAssignStmt", "indexing", 
                   "functionDecl", "paramList", "paramDecl", "functionParam", 
                   "paramList_typeDecl", "functionCall", "argList", "arg", 
                   "lambdaExpr", "returnStmt", "showStmt", "pourStmt", "appendCall", 
                   "removeCall", "lenCall", "ifElseExpr", "elifBranch", 
                   "whileLoop", "forLoop", "expr", "logicExpr", "equalityExpr", 
                   "relationalExpr", "additiveExpr", "multiplicativeExpr", 
                   "powerExpr", "unaryExpr", "primaryExpr", "literal", "listLiteral", 
                   "typeDecl" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    INT_CAST=5
    FLOAT_CAST=6
    STR_CAST=7
    BOOL_CAST=8
    DRIP=9
    POUR=10
    SHOW=11
    LEN=12
    REMOVE=13
    APPEND=14
    RETURN=15
    IF=16
    ELIF=17
    ELSE=18
    MATCH=19
    FUNC=20
    RANGE=21
    IMPORT=22
    ADD=23
    SUB=24
    MUL=25
    DIV=26
    MOD=27
    POW=28
    AND=29
    OR=30
    EQ=31
    NEQ=32
    LT=33
    GT=34
    LE=35
    GE=36
    ARROW=37
    ASSIGN=38
    NOT=39
    LPAREN=40
    RPAREN=41
    LBRACK=42
    RBRACK=43
    COLON=44
    PIPE=45
    SEMI=46
    COMMA=47
    UNDERSCORE=48
    LIST=49
    INT_TYPE=50
    FLOAT_TYPE=51
    BOOL_TYPE=52
    VOID_TYPE=53
    STRING_TYPE=54
    GESHA_TYPE=55
    PARDOS_TYPE=56
    MACHINE_TYPE=57
    INT=58
    BOOL=59
    FLOAT=60
    STRING=61
    ID=62
    LINE_COMMENT=63
    BLOCK_COMMENT=64
    WS=65

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simpleImport(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.SimpleImportContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.SimpleImportContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.SEMI)
            else:
                return self.getToken(Kafe_GrammarParser.SEMI, i)

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.StmtContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.StmtContext,i)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_program

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = Kafe_GrammarParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 80
                self.simpleImport()
                self.state = 81
                self.match(Kafe_GrammarParser.SEMI)
                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 93
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 9222815134235361260) != 0):
                self.state = 88
                self.stmt()
                self.state = 89
                self.match(Kafe_GrammarParser.SEMI)
                self.state = 95
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SimpleImportContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IMPORT(self):
            return self.getToken(Kafe_GrammarParser.IMPORT, 0)

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_simpleImport

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimpleImport" ):
                return visitor.visitSimpleImport(self)
            else:
                return visitor.visitChildren(self)




    def simpleImport(self):

        localctx = Kafe_GrammarParser.SimpleImportContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_simpleImport)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.match(Kafe_GrammarParser.IMPORT)
            self.state = 97
            self.match(Kafe_GrammarParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def varDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.VarDeclContext,0)


        def assignStmt(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.AssignStmtContext,0)


        def indexedAssignStmt(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.IndexedAssignStmtContext,0)


        def functionDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.FunctionDeclContext,0)


        def ifElseExpr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.IfElseExprContext,0)


        def whileLoop(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.WhileLoopContext,0)


        def forLoop(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ForLoopContext,0)


        def returnStmt(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ReturnStmtContext,0)


        def showStmt(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ShowStmtContext,0)


        def appendCall(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.AppendCallContext,0)


        def removeCall(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.RemoveCallContext,0)


        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_stmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStmt" ):
                return visitor.visitStmt(self)
            else:
                return visitor.visitChildren(self)




    def stmt(self):

        localctx = Kafe_GrammarParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_stmt)
        try:
            self.state = 111
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 99
                self.varDecl()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 100
                self.assignStmt()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 101
                self.indexedAssignStmt()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 102
                self.functionDecl()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 103
                self.ifElseExpr()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 104
                self.whileLoop()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 105
                self.forLoop()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 106
                self.returnStmt()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 107
                self.showStmt()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 108
                self.appendCall()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 109
                self.removeCall()
                pass

            elif la_ == 12:
                self.enterOuterAlt(localctx, 12)
                self.state = 110
                self.expr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.StmtContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.StmtContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.SEMI)
            else:
                return self.getToken(Kafe_GrammarParser.SEMI, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)




    def block(self):

        localctx = Kafe_GrammarParser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 9222815134235361260) != 0):
                self.state = 113
                self.stmt()
                self.state = 114
                self.match(Kafe_GrammarParser.SEMI)
                self.state = 120
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ObjectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_object

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ObjectConstantContext(ObjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.ObjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.ID)
            else:
                return self.getToken(Kafe_GrammarParser.ID, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitObjectConstant" ):
                return visitor.visitObjectConstant(self)
            else:
                return visitor.visitChildren(self)


    class ObjectFunctionCallContext(ObjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.ObjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.ID)
            else:
                return self.getToken(Kafe_GrammarParser.ID, i)
        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)
        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.COMMA)
            else:
                return self.getToken(Kafe_GrammarParser.COMMA, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitObjectFunctionCall" ):
                return visitor.visitObjectFunctionCall(self)
            else:
                return visitor.visitChildren(self)



    def object_(self):

        localctx = Kafe_GrammarParser.ObjectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_object)
        self._la = 0 # Token type
        try:
            self.state = 139
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                localctx = Kafe_GrammarParser.ObjectFunctionCallContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 121
                self.match(Kafe_GrammarParser.ID)
                self.state = 122
                self.match(Kafe_GrammarParser.T__0)
                self.state = 123
                self.match(Kafe_GrammarParser.ID)
                self.state = 124
                self.match(Kafe_GrammarParser.LPAREN)
                self.state = 133
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8935147708035896800) != 0):
                    self.state = 125
                    self.expr()
                    self.state = 130
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==47:
                        self.state = 126
                        self.match(Kafe_GrammarParser.COMMA)
                        self.state = 127
                        self.expr()
                        self.state = 132
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 135
                self.match(Kafe_GrammarParser.RPAREN)
                pass

            elif la_ == 2:
                localctx = Kafe_GrammarParser.ObjectConstantContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 136
                self.match(Kafe_GrammarParser.ID)
                self.state = 137
                self.match(Kafe_GrammarParser.T__0)
                self.state = 138
                self.match(Kafe_GrammarParser.ID)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.TypeDeclContext,0)


        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def ASSIGN(self):
            return self.getToken(Kafe_GrammarParser.ASSIGN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_varDecl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarDecl" ):
                return visitor.visitVarDecl(self)
            else:
                return visitor.visitChildren(self)




    def varDecl(self):

        localctx = Kafe_GrammarParser.VarDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_varDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 141
            self.typeDecl()
            self.state = 142
            self.match(Kafe_GrammarParser.ID)
            self.state = 145
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 143
                self.match(Kafe_GrammarParser.ASSIGN)
                self.state = 144
                self.expr()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def ASSIGN(self):
            return self.getToken(Kafe_GrammarParser.ASSIGN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_assignStmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignStmt" ):
                return visitor.visitAssignStmt(self)
            else:
                return visitor.visitChildren(self)




    def assignStmt(self):

        localctx = Kafe_GrammarParser.AssignStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_assignStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 147
            self.match(Kafe_GrammarParser.ID)
            self.state = 148
            self.match(Kafe_GrammarParser.ASSIGN)
            self.state = 149
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IndexedAssignStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def indexing(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.IndexingContext,0)


        def ASSIGN(self):
            return self.getToken(Kafe_GrammarParser.ASSIGN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_indexedAssignStmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexedAssignStmt" ):
                return visitor.visitIndexedAssignStmt(self)
            else:
                return visitor.visitChildren(self)




    def indexedAssignStmt(self):

        localctx = Kafe_GrammarParser.IndexedAssignStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_indexedAssignStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self.match(Kafe_GrammarParser.ID)
            self.state = 152
            self.indexing()
            self.state = 153
            self.match(Kafe_GrammarParser.ASSIGN)
            self.state = 154
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IndexingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACK(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.LBRACK)
            else:
                return self.getToken(Kafe_GrammarParser.LBRACK, i)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,i)


        def RBRACK(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.RBRACK)
            else:
                return self.getToken(Kafe_GrammarParser.RBRACK, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_indexing

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexing" ):
                return visitor.visitIndexing(self)
            else:
                return visitor.visitChildren(self)




    def indexing(self):

        localctx = Kafe_GrammarParser.IndexingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_indexing)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 160 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 156
                self.match(Kafe_GrammarParser.LBRACK)
                self.state = 157
                self.expr()
                self.state = 158
                self.match(Kafe_GrammarParser.RBRACK)
                self.state = 162 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==42):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DRIP(self):
            return self.getToken(Kafe_GrammarParser.DRIP, 0)

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def ARROW(self):
            return self.getToken(Kafe_GrammarParser.ARROW, 0)

        def typeDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.TypeDeclContext,0)


        def COLON(self):
            return self.getToken(Kafe_GrammarParser.COLON, 0)

        def block(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.BlockContext,0)


        def paramList(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ParamListContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_functionDecl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionDecl" ):
                return visitor.visitFunctionDecl(self)
            else:
                return visitor.visitChildren(self)




    def functionDecl(self):

        localctx = Kafe_GrammarParser.FunctionDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_functionDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 164
            self.match(Kafe_GrammarParser.DRIP)
            self.state = 165
            self.match(Kafe_GrammarParser.ID)
            self.state = 166
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 168
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==62:
                self.state = 167
                self.paramList()


            self.state = 170
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 171
            self.match(Kafe_GrammarParser.ARROW)
            self.state = 172
            self.typeDecl()
            self.state = 173
            self.match(Kafe_GrammarParser.COLON)
            self.state = 174
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def paramDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ParamDeclContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ParamDeclContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.COMMA)
            else:
                return self.getToken(Kafe_GrammarParser.COMMA, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_paramList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParamList" ):
                return visitor.visitParamList(self)
            else:
                return visitor.visitChildren(self)




    def paramList(self):

        localctx = Kafe_GrammarParser.ParamListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_paramList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 176
            self.paramDecl()
            self.state = 181
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==47:
                self.state = 177
                self.match(Kafe_GrammarParser.COMMA)
                self.state = 178
                self.paramDecl()
                self.state = 183
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_paramDecl

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SimpleParamContext(ParamDeclContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.ParamDeclContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)
        def COLON(self):
            return self.getToken(Kafe_GrammarParser.COLON, 0)
        def typeDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.TypeDeclContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimpleParam" ):
                return visitor.visitSimpleParam(self)
            else:
                return visitor.visitChildren(self)



    def paramDecl(self):

        localctx = Kafe_GrammarParser.ParamDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_paramDecl)
        try:
            localctx = Kafe_GrammarParser.SimpleParamContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 184
            self.match(Kafe_GrammarParser.ID)
            self.state = 185
            self.match(Kafe_GrammarParser.COLON)
            self.state = 186
            self.typeDecl()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUNC(self):
            return self.getToken(Kafe_GrammarParser.FUNC, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def ARROW(self):
            return self.getToken(Kafe_GrammarParser.ARROW, 0)

        def typeDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.TypeDeclContext,0)


        def paramList_typeDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ParamList_typeDeclContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_functionParam

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionParam" ):
                return visitor.visitFunctionParam(self)
            else:
                return visitor.visitChildren(self)




    def functionParam(self):

        localctx = Kafe_GrammarParser.FunctionParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_functionParam)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 188
            self.match(Kafe_GrammarParser.FUNC)
            self.state = 189
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 191
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 287667426199339008) != 0):
                self.state = 190
                self.paramList_typeDecl()


            self.state = 193
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 194
            self.match(Kafe_GrammarParser.ARROW)
            self.state = 195
            self.typeDecl()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamList_typeDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.TypeDeclContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.TypeDeclContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.COMMA)
            else:
                return self.getToken(Kafe_GrammarParser.COMMA, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_paramList_typeDecl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParamList_typeDecl" ):
                return visitor.visitParamList_typeDecl(self)
            else:
                return visitor.visitChildren(self)




    def paramList_typeDecl(self):

        localctx = Kafe_GrammarParser.ParamList_typeDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_paramList_typeDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 197
            self.typeDecl()
            self.state = 202
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==47:
                self.state = 198
                self.match(Kafe_GrammarParser.COMMA)
                self.state = 199
                self.typeDecl()
                self.state = 204
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def LPAREN(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.LPAREN)
            else:
                return self.getToken(Kafe_GrammarParser.LPAREN, i)

        def RPAREN(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.RPAREN)
            else:
                return self.getToken(Kafe_GrammarParser.RPAREN, i)

        def argList(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ArgListContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ArgListContext,i)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_functionCall

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionCall" ):
                return visitor.visitFunctionCall(self)
            else:
                return visitor.visitChildren(self)




    def functionCall(self):

        localctx = Kafe_GrammarParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_functionCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 205
            self.match(Kafe_GrammarParser.ID)
            self.state = 206
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 208
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8935147708035896800) != 0):
                self.state = 207
                self.argList()


            self.state = 210
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 218
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,15,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 211
                    self.match(Kafe_GrammarParser.LPAREN)
                    self.state = 213
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8935147708035896800) != 0):
                        self.state = 212
                        self.argList()


                    self.state = 215
                    self.match(Kafe_GrammarParser.RPAREN) 
                self.state = 220
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,15,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def arg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ArgContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ArgContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.COMMA)
            else:
                return self.getToken(Kafe_GrammarParser.COMMA, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_argList

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgList" ):
                return visitor.visitArgList(self)
            else:
                return visitor.visitChildren(self)




    def argList(self):

        localctx = Kafe_GrammarParser.ArgListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_argList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 221
            self.arg()
            self.state = 226
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==47:
                self.state = 222
                self.match(Kafe_GrammarParser.COMMA)
                self.state = 223
                self.arg()
                self.state = 228
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_arg

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class LambdaArgumentContext(ArgContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.ArgContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def lambdaExpr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.LambdaExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLambdaArgument" ):
                return visitor.visitLambdaArgument(self)
            else:
                return visitor.visitChildren(self)


    class ExprArgumentContext(ArgContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.ArgContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprArgument" ):
                return visitor.visitExprArgument(self)
            else:
                return visitor.visitChildren(self)



    def arg(self):

        localctx = Kafe_GrammarParser.ArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_arg)
        try:
            self.state = 231
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                localctx = Kafe_GrammarParser.ExprArgumentContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 229
                self.expr()
                pass

            elif la_ == 2:
                localctx = Kafe_GrammarParser.LambdaArgumentContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 230
                self.lambdaExpr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LambdaExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def paramList(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ParamListContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def ARROW(self):
            return self.getToken(Kafe_GrammarParser.ARROW, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_lambdaExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLambdaExpr" ):
                return visitor.visitLambdaExpr(self)
            else:
                return visitor.visitChildren(self)




    def lambdaExpr(self):

        localctx = Kafe_GrammarParser.LambdaExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_lambdaExpr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 233
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 234
            self.paramList()
            self.state = 235
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 236
            self.match(Kafe_GrammarParser.ARROW)
            self.state = 237
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReturnStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(Kafe_GrammarParser.RETURN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_returnStmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturnStmt" ):
                return visitor.visitReturnStmt(self)
            else:
                return visitor.visitChildren(self)




    def returnStmt(self):

        localctx = Kafe_GrammarParser.ReturnStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_returnStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 239
            self.match(Kafe_GrammarParser.RETURN)
            self.state = 240
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShowStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SHOW(self):
            return self.getToken(Kafe_GrammarParser.SHOW, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_showStmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShowStmt" ):
                return visitor.visitShowStmt(self)
            else:
                return visitor.visitChildren(self)




    def showStmt(self):

        localctx = Kafe_GrammarParser.ShowStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_showStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 242
            self.match(Kafe_GrammarParser.SHOW)
            self.state = 243
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 244
            self.expr()
            self.state = 245
            self.match(Kafe_GrammarParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PourStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def POUR(self):
            return self.getToken(Kafe_GrammarParser.POUR, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_pourStmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPourStmt" ):
                return visitor.visitPourStmt(self)
            else:
                return visitor.visitChildren(self)




    def pourStmt(self):

        localctx = Kafe_GrammarParser.PourStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_pourStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 247
            self.match(Kafe_GrammarParser.POUR)
            self.state = 248
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 249
            self.expr()
            self.state = 250
            self.match(Kafe_GrammarParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AppendCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def APPEND(self):
            return self.getToken(Kafe_GrammarParser.APPEND, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,i)


        def COMMA(self):
            return self.getToken(Kafe_GrammarParser.COMMA, 0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_appendCall

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAppendCall" ):
                return visitor.visitAppendCall(self)
            else:
                return visitor.visitChildren(self)




    def appendCall(self):

        localctx = Kafe_GrammarParser.AppendCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_appendCall)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 252
            self.match(Kafe_GrammarParser.APPEND)
            self.state = 253
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 254
            self.expr()
            self.state = 255
            self.match(Kafe_GrammarParser.COMMA)
            self.state = 256
            self.expr()
            self.state = 257
            self.match(Kafe_GrammarParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RemoveCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def REMOVE(self):
            return self.getToken(Kafe_GrammarParser.REMOVE, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,i)


        def COMMA(self):
            return self.getToken(Kafe_GrammarParser.COMMA, 0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_removeCall

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRemoveCall" ):
                return visitor.visitRemoveCall(self)
            else:
                return visitor.visitChildren(self)




    def removeCall(self):

        localctx = Kafe_GrammarParser.RemoveCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_removeCall)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 259
            self.match(Kafe_GrammarParser.REMOVE)
            self.state = 260
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 261
            self.expr()
            self.state = 262
            self.match(Kafe_GrammarParser.COMMA)
            self.state = 263
            self.expr()
            self.state = 264
            self.match(Kafe_GrammarParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LenCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LEN(self):
            return self.getToken(Kafe_GrammarParser.LEN, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_lenCall

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLenCall" ):
                return visitor.visitLenCall(self)
            else:
                return visitor.visitChildren(self)




    def lenCall(self):

        localctx = Kafe_GrammarParser.LenCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_lenCall)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 266
            self.match(Kafe_GrammarParser.LEN)
            self.state = 267
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 268
            self.expr()
            self.state = 269
            self.match(Kafe_GrammarParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfElseExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(Kafe_GrammarParser.IF, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def COLON(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.COLON)
            else:
                return self.getToken(Kafe_GrammarParser.COLON, i)

        def block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.BlockContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.BlockContext,i)


        def elifBranch(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ElifBranchContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ElifBranchContext,i)


        def ELSE(self):
            return self.getToken(Kafe_GrammarParser.ELSE, 0)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_ifElseExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfElseExpr" ):
                return visitor.visitIfElseExpr(self)
            else:
                return visitor.visitChildren(self)




    def ifElseExpr(self):

        localctx = Kafe_GrammarParser.IfElseExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_ifElseExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 271
            self.match(Kafe_GrammarParser.IF)
            self.state = 272
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 273
            self.expr()
            self.state = 274
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 275
            self.match(Kafe_GrammarParser.COLON)
            self.state = 276
            self.block()
            self.state = 280
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==17:
                self.state = 277
                self.elifBranch()
                self.state = 282
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 286
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 283
                self.match(Kafe_GrammarParser.ELSE)
                self.state = 284
                self.match(Kafe_GrammarParser.COLON)
                self.state = 285
                self.block()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElifBranchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELIF(self):
            return self.getToken(Kafe_GrammarParser.ELIF, 0)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def COLON(self):
            return self.getToken(Kafe_GrammarParser.COLON, 0)

        def block(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.BlockContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_elifBranch

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElifBranch" ):
                return visitor.visitElifBranch(self)
            else:
                return visitor.visitChildren(self)




    def elifBranch(self):

        localctx = Kafe_GrammarParser.ElifBranchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_elifBranch)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 288
            self.match(Kafe_GrammarParser.ELIF)
            self.state = 289
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 290
            self.expr()
            self.state = 291
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 292
            self.match(Kafe_GrammarParser.COLON)
            self.state = 293
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileLoopContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def COLON(self):
            return self.getToken(Kafe_GrammarParser.COLON, 0)

        def block(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.BlockContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_whileLoop

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileLoop" ):
                return visitor.visitWhileLoop(self)
            else:
                return visitor.visitChildren(self)




    def whileLoop(self):

        localctx = Kafe_GrammarParser.WhileLoopContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_whileLoop)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 295
            self.match(Kafe_GrammarParser.T__1)
            self.state = 296
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 297
            self.expr()
            self.state = 298
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 299
            self.match(Kafe_GrammarParser.COLON)
            self.state = 300
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForLoopContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def COLON(self):
            return self.getToken(Kafe_GrammarParser.COLON, 0)

        def block(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.BlockContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_forLoop

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForLoop" ):
                return visitor.visitForLoop(self)
            else:
                return visitor.visitChildren(self)




    def forLoop(self):

        localctx = Kafe_GrammarParser.ForLoopContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_forLoop)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.match(Kafe_GrammarParser.T__2)
            self.state = 303
            self.match(Kafe_GrammarParser.LPAREN)
            self.state = 304
            self.match(Kafe_GrammarParser.ID)
            self.state = 305
            self.match(Kafe_GrammarParser.T__3)
            self.state = 306
            self.expr()
            self.state = 307
            self.match(Kafe_GrammarParser.RPAREN)
            self.state = 308
            self.match(Kafe_GrammarParser.COLON)
            self.state = 309
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicExpr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.LogicExprContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_expr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)




    def expr(self):

        localctx = Kafe_GrammarParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 311
            self.logicExpr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def equalityExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.EqualityExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.EqualityExprContext,i)


        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.OR)
            else:
                return self.getToken(Kafe_GrammarParser.OR, i)

        def AND(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.AND)
            else:
                return self.getToken(Kafe_GrammarParser.AND, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_logicExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicExpr" ):
                return visitor.visitLogicExpr(self)
            else:
                return visitor.visitChildren(self)




    def logicExpr(self):

        localctx = Kafe_GrammarParser.LogicExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_logicExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 313
            self.equalityExpr()
            self.state = 318
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,20,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 314
                    _la = self._input.LA(1)
                    if not(_la==29 or _la==30):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 315
                    self.equalityExpr() 
                self.state = 320
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EqualityExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def relationalExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.RelationalExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.RelationalExprContext,i)


        def EQ(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.EQ)
            else:
                return self.getToken(Kafe_GrammarParser.EQ, i)

        def NEQ(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.NEQ)
            else:
                return self.getToken(Kafe_GrammarParser.NEQ, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_equalityExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEqualityExpr" ):
                return visitor.visitEqualityExpr(self)
            else:
                return visitor.visitChildren(self)




    def equalityExpr(self):

        localctx = Kafe_GrammarParser.EqualityExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_equalityExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 321
            self.relationalExpr()
            self.state = 326
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,21,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 322
                    _la = self._input.LA(1)
                    if not(_la==31 or _la==32):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 323
                    self.relationalExpr() 
                self.state = 328
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,21,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelationalExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def additiveExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.AdditiveExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.AdditiveExprContext,i)


        def LT(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.LT)
            else:
                return self.getToken(Kafe_GrammarParser.LT, i)

        def LE(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.LE)
            else:
                return self.getToken(Kafe_GrammarParser.LE, i)

        def GT(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.GT)
            else:
                return self.getToken(Kafe_GrammarParser.GT, i)

        def GE(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.GE)
            else:
                return self.getToken(Kafe_GrammarParser.GE, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_relationalExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelationalExpr" ):
                return visitor.visitRelationalExpr(self)
            else:
                return visitor.visitChildren(self)




    def relationalExpr(self):

        localctx = Kafe_GrammarParser.RelationalExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_relationalExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 329
            self.additiveExpr()
            self.state = 334
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,22,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 330
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 128849018880) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 331
                    self.additiveExpr() 
                self.state = 336
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,22,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def multiplicativeExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.MultiplicativeExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.MultiplicativeExprContext,i)


        def ADD(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.ADD)
            else:
                return self.getToken(Kafe_GrammarParser.ADD, i)

        def SUB(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.SUB)
            else:
                return self.getToken(Kafe_GrammarParser.SUB, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_additiveExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdditiveExpr" ):
                return visitor.visitAdditiveExpr(self)
            else:
                return visitor.visitChildren(self)




    def additiveExpr(self):

        localctx = Kafe_GrammarParser.AdditiveExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_additiveExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 337
            self.multiplicativeExpr()
            self.state = 342
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 338
                    _la = self._input.LA(1)
                    if not(_la==23 or _la==24):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 339
                    self.multiplicativeExpr() 
                self.state = 344
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MultiplicativeExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def powerExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.PowerExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.PowerExprContext,i)


        def MUL(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.MUL)
            else:
                return self.getToken(Kafe_GrammarParser.MUL, i)

        def DIV(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.DIV)
            else:
                return self.getToken(Kafe_GrammarParser.DIV, i)

        def MOD(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.MOD)
            else:
                return self.getToken(Kafe_GrammarParser.MOD, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_multiplicativeExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicativeExpr" ):
                return visitor.visitMultiplicativeExpr(self)
            else:
                return visitor.visitChildren(self)




    def multiplicativeExpr(self):

        localctx = Kafe_GrammarParser.MultiplicativeExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_multiplicativeExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 345
            self.powerExpr()
            self.state = 350
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,24,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 346
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 234881024) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 347
                    self.powerExpr() 
                self.state = 352
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,24,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PowerExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unaryExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.UnaryExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.UnaryExprContext,i)


        def POW(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.POW)
            else:
                return self.getToken(Kafe_GrammarParser.POW, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_powerExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPowerExpr" ):
                return visitor.visitPowerExpr(self)
            else:
                return visitor.visitChildren(self)




    def powerExpr(self):

        localctx = Kafe_GrammarParser.PowerExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_powerExpr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 353
            self.unaryExpr()
            self.state = 358
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,25,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 354
                    self.match(Kafe_GrammarParser.POW)
                    self.state = 355
                    self.unaryExpr() 
                self.state = 360
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,25,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnaryExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_unaryExpr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class PrimaryExpressionContext(UnaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.UnaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def primaryExpr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.PrimaryExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimaryExpression" ):
                return visitor.visitPrimaryExpression(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExpressionContext(UnaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.UnaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def unaryExpr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.UnaryExprContext,0)

        def SUB(self):
            return self.getToken(Kafe_GrammarParser.SUB, 0)
        def NOT(self):
            return self.getToken(Kafe_GrammarParser.NOT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpression" ):
                return visitor.visitUnaryExpression(self)
            else:
                return visitor.visitChildren(self)



    def unaryExpr(self):

        localctx = Kafe_GrammarParser.UnaryExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_unaryExpr)
        self._la = 0 # Token type
        try:
            self.state = 364
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [24, 39]:
                localctx = Kafe_GrammarParser.UnaryExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 361
                _la = self._input.LA(1)
                if not(_la==24 or _la==39):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 362
                self.unaryExpr()
                pass
            elif token in [5, 6, 7, 8, 10, 12, 21, 40, 42, 58, 59, 60, 61, 62]:
                localctx = Kafe_GrammarParser.PrimaryExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 363
                self.primaryExpr(0)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_primaryExpr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class FloatCastExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FLOAT_CAST(self):
            return self.getToken(Kafe_GrammarParser.FLOAT_CAST, 0)
        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)
        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatCastExpr" ):
                return visitor.visitFloatCastExpr(self)
            else:
                return visitor.visitChildren(self)


    class LambdaExpressionContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def lambdaExpr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.LambdaExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLambdaExpression" ):
                return visitor.visitLambdaExpression(self)
            else:
                return visitor.visitChildren(self)


    class ObjectExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def object_(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ObjectContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitObjectExpr" ):
                return visitor.visitObjectExpr(self)
            else:
                return visitor.visitChildren(self)


    class IntCastExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT_CAST(self):
            return self.getToken(Kafe_GrammarParser.INT_CAST, 0)
        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)
        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntCastExpr" ):
                return visitor.visitIntCastExpr(self)
            else:
                return visitor.visitChildren(self)


    class IndexingExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def primaryExpr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.PrimaryExprContext,0)

        def LBRACK(self):
            return self.getToken(Kafe_GrammarParser.LBRACK, 0)
        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)

        def RBRACK(self):
            return self.getToken(Kafe_GrammarParser.RBRACK, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexingExpr" ):
                return visitor.visitIndexingExpr(self)
            else:
                return visitor.visitChildren(self)


    class StrCastExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STR_CAST(self):
            return self.getToken(Kafe_GrammarParser.STR_CAST, 0)
        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)
        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStrCastExpr" ):
                return visitor.visitStrCastExpr(self)
            else:
                return visitor.visitChildren(self)


    class LenCallExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def lenCall(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.LenCallContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLenCallExpr" ):
                return visitor.visitLenCallExpr(self)
            else:
                return visitor.visitChildren(self)


    class ParenExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)
        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParenExpr" ):
                return visitor.visitParenExpr(self)
            else:
                return visitor.visitChildren(self)


    class BoolCastExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def BOOL_CAST(self):
            return self.getToken(Kafe_GrammarParser.BOOL_CAST, 0)
        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)
        def expr(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,0)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolCastExpr" ):
                return visitor.visitBoolCastExpr(self)
            else:
                return visitor.visitChildren(self)


    class PourExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def pourStmt(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.PourStmtContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPourExpr" ):
                return visitor.visitPourExpr(self)
            else:
                return visitor.visitChildren(self)


    class LiteralExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def literal(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.LiteralContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteralExpr" ):
                return visitor.visitLiteralExpr(self)
            else:
                return visitor.visitChildren(self)


    class FunctionCallExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def functionCall(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.FunctionCallContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionCallExpr" ):
                return visitor.visitFunctionCallExpr(self)
            else:
                return visitor.visitChildren(self)


    class RangeExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def RANGE(self):
            return self.getToken(Kafe_GrammarParser.RANGE, 0)
        def LPAREN(self):
            return self.getToken(Kafe_GrammarParser.LPAREN, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,i)

        def RPAREN(self):
            return self.getToken(Kafe_GrammarParser.RPAREN, 0)
        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.COMMA)
            else:
                return self.getToken(Kafe_GrammarParser.COMMA, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRangeExpr" ):
                return visitor.visitRangeExpr(self)
            else:
                return visitor.visitChildren(self)


    class IdExprContext(PrimaryExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.PrimaryExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(Kafe_GrammarParser.ID, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdExpr" ):
                return visitor.visitIdExpr(self)
            else:
                return visitor.visitChildren(self)



    def primaryExpr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = Kafe_GrammarParser.PrimaryExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 72
        self.enterRecursionRule(localctx, 72, self.RULE_primaryExpr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 411
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
            if la_ == 1:
                localctx = Kafe_GrammarParser.ObjectExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 367
                self.object_()
                pass

            elif la_ == 2:
                localctx = Kafe_GrammarParser.FunctionCallExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 368
                self.functionCall()
                pass

            elif la_ == 3:
                localctx = Kafe_GrammarParser.PourExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 369
                self.pourStmt()
                pass

            elif la_ == 4:
                localctx = Kafe_GrammarParser.LenCallExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 370
                self.lenCall()
                pass

            elif la_ == 5:
                localctx = Kafe_GrammarParser.RangeExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 371
                self.match(Kafe_GrammarParser.RANGE)
                self.state = 372
                self.match(Kafe_GrammarParser.LPAREN)
                self.state = 373
                self.expr()
                self.state = 376
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
                if la_ == 1:
                    self.state = 374
                    self.match(Kafe_GrammarParser.COMMA)
                    self.state = 375
                    self.expr()


                self.state = 380
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==47:
                    self.state = 378
                    self.match(Kafe_GrammarParser.COMMA)
                    self.state = 379
                    self.expr()


                self.state = 382
                self.match(Kafe_GrammarParser.RPAREN)
                pass

            elif la_ == 6:
                localctx = Kafe_GrammarParser.IntCastExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 384
                self.match(Kafe_GrammarParser.INT_CAST)
                self.state = 385
                self.match(Kafe_GrammarParser.LPAREN)
                self.state = 386
                self.expr()
                self.state = 387
                self.match(Kafe_GrammarParser.RPAREN)
                pass

            elif la_ == 7:
                localctx = Kafe_GrammarParser.FloatCastExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 389
                self.match(Kafe_GrammarParser.FLOAT_CAST)
                self.state = 390
                self.match(Kafe_GrammarParser.LPAREN)
                self.state = 391
                self.expr()
                self.state = 392
                self.match(Kafe_GrammarParser.RPAREN)
                pass

            elif la_ == 8:
                localctx = Kafe_GrammarParser.StrCastExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 394
                self.match(Kafe_GrammarParser.STR_CAST)
                self.state = 395
                self.match(Kafe_GrammarParser.LPAREN)
                self.state = 396
                self.expr()
                self.state = 397
                self.match(Kafe_GrammarParser.RPAREN)
                pass

            elif la_ == 9:
                localctx = Kafe_GrammarParser.BoolCastExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 399
                self.match(Kafe_GrammarParser.BOOL_CAST)
                self.state = 400
                self.match(Kafe_GrammarParser.LPAREN)
                self.state = 401
                self.expr()
                self.state = 402
                self.match(Kafe_GrammarParser.RPAREN)
                pass

            elif la_ == 10:
                localctx = Kafe_GrammarParser.LambdaExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 404
                self.lambdaExpr()
                pass

            elif la_ == 11:
                localctx = Kafe_GrammarParser.LiteralExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 405
                self.literal()
                pass

            elif la_ == 12:
                localctx = Kafe_GrammarParser.IdExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 406
                self.match(Kafe_GrammarParser.ID)
                pass

            elif la_ == 13:
                localctx = Kafe_GrammarParser.ParenExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 407
                self.match(Kafe_GrammarParser.LPAREN)
                self.state = 408
                self.expr()
                self.state = 409
                self.match(Kafe_GrammarParser.RPAREN)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 420
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,30,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = Kafe_GrammarParser.IndexingExprContext(self, Kafe_GrammarParser.PrimaryExprContext(self, _parentctx, _parentState))
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_primaryExpr)
                    self.state = 413
                    if not self.precpred(self._ctx, 14):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 14)")
                    self.state = 414
                    self.match(Kafe_GrammarParser.LBRACK)
                    self.state = 415
                    self.expr()
                    self.state = 416
                    self.match(Kafe_GrammarParser.RBRACK) 
                self.state = 422
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class LiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_literal

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class StringLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(Kafe_GrammarParser.STRING, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringLiteral" ):
                return visitor.visitStringLiteral(self)
            else:
                return visitor.visitChildren(self)


    class ListLiteralExprContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def listLiteral(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.ListLiteralContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListLiteralExpr" ):
                return visitor.visitListLiteralExpr(self)
            else:
                return visitor.visitChildren(self)


    class IntLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(Kafe_GrammarParser.INT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntLiteral" ):
                return visitor.visitIntLiteral(self)
            else:
                return visitor.visitChildren(self)


    class FloatLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FLOAT(self):
            return self.getToken(Kafe_GrammarParser.FLOAT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatLiteral" ):
                return visitor.visitFloatLiteral(self)
            else:
                return visitor.visitChildren(self)


    class BoolLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a Kafe_GrammarParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def BOOL(self):
            return self.getToken(Kafe_GrammarParser.BOOL, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolLiteral" ):
                return visitor.visitBoolLiteral(self)
            else:
                return visitor.visitChildren(self)



    def literal(self):

        localctx = Kafe_GrammarParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_literal)
        try:
            self.state = 428
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [58]:
                localctx = Kafe_GrammarParser.IntLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 423
                self.match(Kafe_GrammarParser.INT)
                pass
            elif token in [60]:
                localctx = Kafe_GrammarParser.FloatLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 424
                self.match(Kafe_GrammarParser.FLOAT)
                pass
            elif token in [61]:
                localctx = Kafe_GrammarParser.StringLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 425
                self.match(Kafe_GrammarParser.STRING)
                pass
            elif token in [59]:
                localctx = Kafe_GrammarParser.BoolLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 426
                self.match(Kafe_GrammarParser.BOOL)
                pass
            elif token in [42]:
                localctx = Kafe_GrammarParser.ListLiteralExprContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 427
                self.listLiteral()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACK(self):
            return self.getToken(Kafe_GrammarParser.LBRACK, 0)

        def RBRACK(self):
            return self.getToken(Kafe_GrammarParser.RBRACK, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Kafe_GrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(Kafe_GrammarParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(Kafe_GrammarParser.COMMA)
            else:
                return self.getToken(Kafe_GrammarParser.COMMA, i)

        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_listLiteral

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListLiteral" ):
                return visitor.visitListLiteral(self)
            else:
                return visitor.visitChildren(self)




    def listLiteral(self):

        localctx = Kafe_GrammarParser.ListLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_listLiteral)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 430
            self.match(Kafe_GrammarParser.LBRACK)
            self.state = 439
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8935147708035896800) != 0):
                self.state = 431
                self.expr()
                self.state = 436
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==47:
                    self.state = 432
                    self.match(Kafe_GrammarParser.COMMA)
                    self.state = 433
                    self.expr()
                    self.state = 438
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 441
            self.match(Kafe_GrammarParser.RBRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT_TYPE(self):
            return self.getToken(Kafe_GrammarParser.INT_TYPE, 0)

        def FLOAT_TYPE(self):
            return self.getToken(Kafe_GrammarParser.FLOAT_TYPE, 0)

        def BOOL_TYPE(self):
            return self.getToken(Kafe_GrammarParser.BOOL_TYPE, 0)

        def VOID_TYPE(self):
            return self.getToken(Kafe_GrammarParser.VOID_TYPE, 0)

        def STRING_TYPE(self):
            return self.getToken(Kafe_GrammarParser.STRING_TYPE, 0)

        def GESHA_TYPE(self):
            return self.getToken(Kafe_GrammarParser.GESHA_TYPE, 0)

        def PARDOS_TYPE(self):
            return self.getToken(Kafe_GrammarParser.PARDOS_TYPE, 0)

        def MACHINE_TYPE(self):
            return self.getToken(Kafe_GrammarParser.MACHINE_TYPE, 0)

        def LIST(self):
            return self.getToken(Kafe_GrammarParser.LIST, 0)

        def LBRACK(self):
            return self.getToken(Kafe_GrammarParser.LBRACK, 0)

        def typeDecl(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.TypeDeclContext,0)


        def RBRACK(self):
            return self.getToken(Kafe_GrammarParser.RBRACK, 0)

        def functionParam(self):
            return self.getTypedRuleContext(Kafe_GrammarParser.FunctionParamContext,0)


        def getRuleIndex(self):
            return Kafe_GrammarParser.RULE_typeDecl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeDecl" ):
                return visitor.visitTypeDecl(self)
            else:
                return visitor.visitChildren(self)




    def typeDecl(self):

        localctx = Kafe_GrammarParser.TypeDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_typeDecl)
        try:
            self.state = 457
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [50]:
                self.enterOuterAlt(localctx, 1)
                self.state = 443
                self.match(Kafe_GrammarParser.INT_TYPE)
                pass
            elif token in [51]:
                self.enterOuterAlt(localctx, 2)
                self.state = 444
                self.match(Kafe_GrammarParser.FLOAT_TYPE)
                pass
            elif token in [52]:
                self.enterOuterAlt(localctx, 3)
                self.state = 445
                self.match(Kafe_GrammarParser.BOOL_TYPE)
                pass
            elif token in [53]:
                self.enterOuterAlt(localctx, 4)
                self.state = 446
                self.match(Kafe_GrammarParser.VOID_TYPE)
                pass
            elif token in [54]:
                self.enterOuterAlt(localctx, 5)
                self.state = 447
                self.match(Kafe_GrammarParser.STRING_TYPE)
                pass
            elif token in [55]:
                self.enterOuterAlt(localctx, 6)
                self.state = 448
                self.match(Kafe_GrammarParser.GESHA_TYPE)
                pass
            elif token in [56]:
                self.enterOuterAlt(localctx, 7)
                self.state = 449
                self.match(Kafe_GrammarParser.PARDOS_TYPE)
                pass
            elif token in [57]:
                self.enterOuterAlt(localctx, 8)
                self.state = 450
                self.match(Kafe_GrammarParser.MACHINE_TYPE)
                pass
            elif token in [49]:
                self.enterOuterAlt(localctx, 9)
                self.state = 451
                self.match(Kafe_GrammarParser.LIST)
                self.state = 452
                self.match(Kafe_GrammarParser.LBRACK)
                self.state = 453
                self.typeDecl()
                self.state = 454
                self.match(Kafe_GrammarParser.RBRACK)
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 10)
                self.state = 456
                self.functionParam()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[36] = self.primaryExpr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def primaryExpr_sempred(self, localctx:PrimaryExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 14)
         




