from typing import cast

from errors import (
    raiseFunctionAlreadyDefined,
    raiseFunctionNotDefined,
    raiseSignatureMismatch,
    raiseVoidAsParameterType,
    raiseWrongNumberOfArgs,
)
from global_utils import assign_variable, check_sig
from Kafe_GrammarParser import Kafe_GrammarParser
from TypeUtils import all_types, any_list_types, function_type, integer_type, void_t

from .utils import ReturnValue, _parse_signature, check_value_type


def _get_top_params(signature: str) -> list[str]:
    s = signature.replace(" ", "")
    if not s.startswith("FUNC("):
        return []
    inner = s[len("FUNC(") :]
    idx = inner.find(")")
    params = inner[:idx]
    return params.split(",") if params else []


def functionDecl(self, ctx):
    name = ctx.ID().getText()
    if name in self.variables:
        existing_type, _ = self.variables[name]
        if existing_type == function_type:
            raiseFunctionAlreadyDefined(name)

    param_lists = ctx.getTypedRuleContexts(Kafe_GrammarParser.ParamListContext)
    params_flat = []
    param_groups = []
    for pl in param_lists:
        grp = []
        for p in pl.paramDecl():
            t = p.typeDecl().getText().replace(" ", "")
            grp.append(t)
            params_flat.append(p)
        param_groups.append(grp)

    for p in params_flat:
        if p.typeDecl().getText().replace(" ", "") == void_t:
            raiseVoidAsParameterType()
    ret_type = ctx.typeDecl().getText().replace(" ", "")
    body = ctx.block()
    outer = self
    total = len(params_flat)
    captured = dict(self.variables)  # Capture current scope for nested functions

    if param_groups:
        prefix = "".join(f"FUNC({','.join(grp)})=>" for grp in param_groups)
        full_sig = prefix + ret_type
    else:
        full_sig = f"FUNC()=>{ret_type}"

    class KafeFunction:
        def __init__(self, collected=None):
            self.collected = collected[:] if collected else []
            self._name = name
            self._signature = full_sig
            self._total = total

        @property
        def signature(self):
            return self._signature

        def __str__(self):
            raise Exception(
                f"'{self._name}' expects {self._total} args, got {len(self.collected)}"
            )

        __repr__ = __str__

        def __call__(self, *args):
            ncol = len(self.collected) + len(args)
            if ncol > self._total:
                raiseWrongNumberOfArgs(self._name, self._total, ncol)

            new_vals = self.collected + list(args)
            if ncol < self._total:
                return KafeFunction(new_vals)

            if captured is not None:
                saved = outer.variables
                saved_scope_stack = outer.scope_stack
                outer.variables = dict(captured)
            else:
                saved = dict(outer.variables)
                saved_scope_stack = outer.scope_stack[:]

            try:
                for decl, val in zip(params_flat, new_vals, strict=False):
                    expected = decl.typeDecl().getText().replace(" ", "")

                    obtained_signature = getattr(val, "signature", None)
                    if obtained_signature:
                        act_p, act_r = _parse_signature(cast(str, obtained_signature))
                        exp_p, exp_r = _parse_signature(expected)
                        # Allow ANY return type to match any expected return type
                        if not (
                            act_p == exp_p
                            and (act_r == exp_r or act_r == "ANY" or exp_r == "ANY")
                        ):
                            top_act = _get_top_params(obtained_signature)
                            top_exp = _get_top_params(expected)
                            if len(top_act) != len(top_exp):
                                pname = decl.ID().getText()
                                raise TypeError(
                                    f"Function parameter '{pname}' "
                                    f"must accept {len(top_exp)} parameter(s), "
                                    f"but got {len(top_act)}."
                                )

                    check_value_type(val, expected)

                    pid = decl.ID().getText()
                    ptype = function_type if expected.startswith("FUNC") else expected
                    assign_variable(outer, pid, val, ptype)

                outer.scope_stack = [{}]  # Fresh scope stack for function
                result = None
                try:
                    outer.visit(body)
                except ReturnValue as rv:
                    result = rv.value
            finally:
                outer.variables = saved
                outer.scope_stack = saved_scope_stack

            if ret_type.startswith("FUNC"):
                sig_ret = getattr(result, "signature", None)
                if sig_ret is None:
                    raiseSignatureMismatch(ret_type, "")

                act_p, act_r = _parse_signature(cast(str, sig_ret))
                exp_p, exp_r = _parse_signature(ret_type)

                # Allow ANY return type from lambdas to match any expected return type
                if act_p != exp_p or (
                    act_r != exp_r and act_r != "ANY" and exp_r != "ANY"
                ):
                    raiseSignatureMismatch(ret_type, sig_ret)
            else:
                check_value_type(result, ret_type)

            return result

    func_obj = KafeFunction()
    if captured is not None:
        captured[name] = (function_type, func_obj)
    self.variables[name] = (function_type, func_obj)


def lambdaExpr(self, ctx):
    params = (
        ctx.paramList().paramDecl()
        if hasattr(ctx, "paramList") and ctx.paramList()
        else [ctx.paramDecl()]
    )

    for p in params:
        if p.typeDecl().getText().replace(" ", "") == void_t:
            raiseVoidAsParameterType()

    in_types = [p.typeDecl().getText().replace(" ", "") for p in params]
    lam_sig = f"FUNC({','.join(in_types)})=>ANY"
    total = len(params)
    body = ctx.expr()
    captured = dict(self.variables)
    outer = self

    class LambdaFn:
        def __init__(self, collected=None):
            self.collected = collected[:] if collected else []
            self._signature = lam_sig
            self._total = total

        @property
        def signature(self):
            return self._signature

        def __str__(self):
            raise Exception(
                f"'<lambda>' expects {self._total} args, got {len(self.collected)}"
            )

        __repr__ = __str__

        def __call__(self, *args):
            ncol = len(self.collected) + len(args)
            if ncol > self._total:
                raiseWrongNumberOfArgs("<lambda>", self._total, ncol)

            new_vals = self.collected + list(args)
            if ncol < self._total:
                return LambdaFn(new_vals)

            saved = outer.variables
            saved_scope_stack = outer.scope_stack
            outer.variables = dict(captured)
            outer.scope_stack = [{}]  # Fresh scope stack for lambda
            try:
                for decl, val in zip(params, new_vals, strict=False):
                    expected = decl.typeDecl().getText().replace(" ", "")

                    obtained_signature = getattr(val, "signature", None)
                    if obtained_signature:
                        act_p, act_r = _parse_signature(obtained_signature)
                        exp_p, exp_r = _parse_signature(expected)
                        # Allow ANY return type to match any expected return type
                        if not (
                            act_p == exp_p
                            and (act_r == exp_r or act_r == "ANY" or exp_r == "ANY")
                        ):
                            top_act = _get_top_params(obtained_signature)
                            top_exp = _get_top_params(expected)
                            if len(top_act) != len(top_exp):
                                pname = decl.ID().getText()
                                raise TypeError(
                                    f"Function parameter '{pname}' "
                                    f"must accept {len(top_exp)} parameter(s), "
                                    f"but got {len(top_act)}."
                                )

                    check_value_type(val, expected)
                    pid = decl.ID().getText()
                    ptype = function_type if expected.startswith("FUNC") else expected
                    assign_variable(outer, pid, val, ptype)

                return outer.visit(body)
            finally:
                outer.variables = saved
                outer.scope_stack = saved_scope_stack

    return LambdaFn()


def functionCall(self, ctx):
    name = ctx.ID().getText()
    if name not in self.variables:
        raiseFunctionNotDefined(name)
    func = self.variables[name][1]
    for arg_list_ctx in ctx.argList():
        args = [self.visit(a) for a in arg_list_ctx.arg()]
        func = func(*args)
    for _ in range(len(ctx.LPAREN()) - len(ctx.argList())):
        func = func()
    return func


def returnStmt(self, ctx):
    raise ReturnValue(self.visit(ctx.expr()))


@check_sig([2], any_list_types, all_types, function_name="append")
def visitAppendCall(items, element):
    items.append(element)


@check_sig([2], any_list_types, all_types, function_name="remove")
def visitRemoveCall(items, element):
    items.remove(element)
    return None


@check_sig([1], any_list_types, function_name="len")
def visitLenCall(items):
    return len(items)


@check_sig([1, 2, 3], [integer_type], [integer_type], [integer_type], function_name="range")
def rangeExpr(*args):
    if len(args) == 1:
        return list(range(args[0]))
    elif len(args) == 2:
        return list(range(args[0], args[1]))
    else:
        return list(range(args[0], args[1], args[2]))


def showStmt(self, ctx):
    val = self.visit(ctx.expr())
    if (
        hasattr(val, "_total")
        and hasattr(val, "collected")
        and len(val.collected) < val._total
    ):
        raiseWrongNumberOfArgs(getattr(val, '_name', '<lambda>'), val._total, len(val.collected))
    print(val)


def pourStmt(self, ctx):
    return input(self.visit(ctx.expr()))
