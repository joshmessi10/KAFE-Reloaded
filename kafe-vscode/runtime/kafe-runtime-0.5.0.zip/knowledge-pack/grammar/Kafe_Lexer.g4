lexer grammar Kafe_Lexer;

//  Casting
INT_CAST    : 'int';
FLOAT_CAST  : 'float';
STR_CAST    : 'str';
BOOL_CAST   : 'bool';


//  Keywords and functions
DRIP        : 'drip';
POUR        : 'pour';
SHOW        : 'show';
LEN        : 'len';
REMOVE     : 'remove';
APPEND     : 'append';
RETURN      : 'return';
IF          : 'if';
ELIF        : 'elif';
ELSE        : 'else';
MATCH       : 'match';
FUNC        : 'FUNC';
RANGE      :  'range';
IMPORT      : 'import';


//  Operators
ADD         : '+';
SUB         : '-';
MUL         : '*';
DIV         : '/';
MOD         : '%';
POW         : '^';
AND         : '&&';
OR          : '||';
EQ          : '==';
NEQ         : '!=';
LT          : '<';
GT          : '>';
LE          : '<=';
GE          : '>=';
ARROW       : '=>';
ASSIGN      : '=';
NOT         : '!';


//  Grouping and separation symbols
LPAREN      : '(';
RPAREN      : ')';
LBRACK      : '[';
RBRACK      : ']';
COLON       : ':';
PIPE        : '|';
SEMI        : ';';
COMMA       : ',';
UNDERSCORE  : '_';


//  Basic types
LIST        : 'List';
INT_TYPE    : 'INT';
FLOAT_TYPE  : 'FLOAT';
BOOL_TYPE   : 'BOOL';
VOID_TYPE   : 'VOID';
STRING_TYPE : 'STR';
GESHA_TYPE  : 'GESHA';
PARDOS_TYPE : 'PARDOS';
MACHINE_TYPE : 'MACHINE';


//  Literals
INT         : [0-9]+;
BOOL        : 'True' | 'False';
FLOAT       : [0-9]+ '.' [0-9]+ ([eE] [+-]? [0-9]+)?
            | [0-9]+ [eE] [+-]? [0-9]+
            ;
STRING
    : '"' ( ~["\\\r\n] | '\\' . )* '"'
    | '\'' ( ~['\\\r\n] | '\\' . )* '\''
    ;

//  Identifiers
ID          : [a-zA-Z_] [a-zA-Z0-9_]*;


//  Comments and whitespace
LINE_COMMENT  : '--' ~[\r\n]*        -> skip;
BLOCK_COMMENT : '->' ( BLOCK_COMMENT | ~[<] | '<' ~[-] )* '<-' -> skip;
WS            : [ \t\r\n]+           -> skip;
